BellSoft Liberica is a build of OpenJDK that is verified to be compliant with the Java SE
specification using OpenJDK Technology Compatibility Kit test suite.

To check BellSoft Liberica details and updates, please visit https://bell-sw.com/liberica.
